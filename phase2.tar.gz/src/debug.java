import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class debug
{
    public static void print(ArrayList<ArrayList<Integer>> board)
    {//debug.print(board);
        for(int i=0; i<board.size(); i++)
		{
			for(int j=0; j<board.size(); j++)
				System.out.printf("%d\t", board.get(i).get(j));
			System.out.println();
            System.out.println();
		}
    }
}