public interface ChessStateInterface
{
    
}