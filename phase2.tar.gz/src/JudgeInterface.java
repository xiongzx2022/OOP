public interface JudgeInterface
{
    
}