import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class demo
{
    public static void main(String[] args)
    {
        BoardUI bui = new BoardUI();
        bui.constructUI();

        /*
        Scanner scan = new Scanner(System.in);

        if (scan.hasNext()) {
            String str1 = scan.next();
            System.out.println("输入的数据为：" + str1);
            bui.text_pane.addText(str1);
        }
        scan.close();
        */
        
    }
}