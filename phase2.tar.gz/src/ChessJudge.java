import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class ChessJudge implements JudgeInterface
{

    public boolean makeMove(BoardUI ui, ChessState state, int x, int y){
        int fix_x = (x-BoardPanel.x+BoardPanel.width/2) / BoardPanel.width * BoardPanel.width + BoardPanel.x;
		int fix_y = (y-BoardPanel.y+BoardPanel.height/2) / BoardPanel.height * BoardPanel.height + BoardPanel.y;

		int idx_x = (fix_x-BoardPanel.x) / BoardPanel.width;
		int idx_y = (fix_y-BoardPanel.y) / BoardPanel.height;

		ArrayList<ArrayList<Integer>> board = state.getChessPos();

		if((idx_x<0)||(idx_y<0)||(idx_x>=board.size())||(idx_y>=board.size()))
		{
			JOptionPane.showMessageDialog(null, "不能在棋盘外面落子", "落子非法", JOptionPane.ERROR_MESSAGE);
			return false;
		}

		if(board.get(idx_x).get(idx_y) != 0)
		{
			JOptionPane.showMessageDialog(null, "此处已经有棋子了，不能重复落子", "落子非法", JOptionPane.ERROR_MESSAGE);
			return false;
		}

		board.get(idx_x).set(idx_y, state.getTurn());
		if(!ChessJudge.takeMove(ui, state))
		if(isAlive(board, idx_x, idx_y) == false)
		{
			board.get(idx_x).set(idx_y, 0);
			JOptionPane.showMessageDialog(null, "这个地方没有气", "落子非法", JOptionPane.ERROR_MESSAGE);
			return false;
		}

		Image chess;
		if(state.getTurn() == 1)
		{	
			ui.text_pane.addText(String.format("黑方在（%s，%d）落子\n", Character.toString((char)((int)'A'+idx_y)), idx_x+1));
			chess = new ImageIcon("../pic/black.png").getImage();
		}
		else
		{
			ui.text_pane.addText(String.format("白方在（%s，%d）落子\n", Character.toString((char)((int)'A'+idx_y)), idx_x+1));
			chess = new ImageIcon("../pic/white.png").getImage();
		}
		Graphics graphics = ui.board_panel.getGraphics();
		graphics.drawImage(chess, fix_x-BoardPanel.width/2, fix_y-BoardPanel.height/2, BoardPanel.width, BoardPanel.height, null);
		
		state.x_history.push(idx_x);
		state.y_history.push(idx_y);

		return true;
    }

	public void pass(ChessState state){
		state.change();
	}

	public ChessState regret(ChessState state){
		ArrayList<ArrayList<Integer>> chess_pos = state.getChessPos();

		for(int i=0; i<2; i++)
		{
			int x = state.x_history.pop();
			int y = state.y_history.pop();
			chess_pos.get(x).set(y, 0);
		}
		state.setChessPos(chess_pos);
		return state;
	}

	public boolean takeMove(BoardUI ui, ChessState state){
		ArrayList<ArrayList<Integer>> board = state.getChessPos();
		int size = board.size();
		Stack<Integer> x_take = new Stack<Integer>();
		Stack<Integer> y_take = new Stack<Integer>();

		for(int i=0; i<size; i++)
			for(int j=0; j<size; j++)
			{
				if(board.get(i).get(j) == 0)
					continue;
				else if(board.get(i).get(j) == -1 * state.getTurn() && isAlive(board, i, j) == false)
				{
					x_take.push(i);
					y_take.push(j);
				}
			}
		String player = "";	//取对方子
		if(state.getTurn() == -1)
			player = "黑方";
		else
			player = "白方";

		boolean flag = false;
		while(!x_take.empty())
		{
			flag = true;
			int x = x_take.pop();
			int y = y_take.pop();
			state.getChessPos().get(x).set(y,0);

			ui.text_pane.addText(String.format("取（%s，%d）" + player + "棋子\n", Character.toString((char)((int)'A'+y)), x+1));
		}

		return flag;
	}

	private static boolean DFS(ArrayList<ArrayList<Integer>> board, boolean[][] visit, int x, int y){
		visit[x][y] = true;
		int[][] xy = {{x-1,y}, {x+1,y}, {x,y-1}, {x,y+1}};
		boolean flag = false;
		for(int i=0; i<xy.length; i++)
		{
			int dx = xy[i][0];
			int dy = xy[i][1];
			if(dx<0 || dx>=visit.length || dy<0 || dy>=visit.length)
				continue;
			else if(visit[dx][dy] == false)
			{
				if(board.get(dx).get(dy) == 0)
					flag = true;
				else if(board.get(dx).get(dy) == -1 * board.get(x).get(y))
					continue;
				else if(board.get(dx).get(dy) == board.get(x).get(y))
					flag = flag || DFS(board, visit, dx, dy);
			}
		}
		return flag;
	}

	private static boolean isAlive(ArrayList<ArrayList<Integer>> board, int x, int y){
		int size = board.size();
		boolean[][] visit = new boolean[size][size];
		for(int i=0; i<size; i++)
			for(int j=0; j<size; j++)
				visit[i][j] = false;
		return DFS(board, visit, x, y);
	}
}