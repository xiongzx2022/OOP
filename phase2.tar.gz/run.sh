rm ./bin/*.class
javac -g ./src/demo.java -sourcepath ./src/ -d ./bin/
java -classpath ./bin/ demo
