import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class ChessStateMemento implements ChessStateInterface, Serializable
{
    public ArrayList<ArrayList<Integer>> state;
    public int turn = 1;
    public String type;

    public ChessStateMemento(ArrayList<ArrayList<Integer>> state, int turn, String type)
    {
        this.state = state;
        this.turn = turn;
        this.type = type;
    }

    public ArrayList<ArrayList<Integer>> getChessPos()
    {
        return this.state;
    }

    public int getTurn()
    {
        return this.turn;
    }

    public String getType()
    {
        return this.type;
    }
}