import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class BaseJudge
{
    public static void saveGame(ChessStateCareTaker state_taker, ChessState state)
    {
        String file_name = JOptionPane.showInputDialog("请输入存档名字：");
        state_taker.saveMemento(state.createMemento(), file_name);
    }

    public static ChessState loadGame(ChessStateCareTaker state_taker, ChessState state)
    {
        String file_name = JOptionPane.showInputDialog("请输入要读取的存档名字：");
        state_taker.loadMemento(file_name);
        state.restoreMemento(state_taker.retrieveMemento());
        
        return state;
    }

    public static ChessState selectGame(BoardUI ui)
    {
        String[] game_types = {"围棋", "五子棋"};
		int type = JOptionPane.showOptionDialog(null, "您是想玩围棋呢，还是想玩五子棋呢？", "请选择您的游戏", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, game_types, game_types[0]);

        Object[] size_options = new Object[12];
        for(int i=8; i<=19; i++)
            size_options[i-8] = String.valueOf(i)+"*"+String.valueOf(i);
        Object board_size = JOptionPane.showInputDialog(null, "棋盘大小可以从8*8到19*19之间选择", "请选择棋盘大小", JOptionPane.PLAIN_MESSAGE, null, size_options, size_options[0]);

        int idx = 0;
        for(; idx<size_options.length; idx++)
            if(size_options[idx].equals(board_size))
                break;

        ui.createBoard(idx+8);
        return new ChessState(idx+8, game_types[type]);
    }

    public static void giveUp(BoardUI ui, ChessState state){
        String name = "";
        if(state.getTurn()==1) name = "黑方";
        if(state.getTurn()==-1) name = "白方";

        JOptionPane.showMessageDialog(null, name + "获胜", "游戏结束", JOptionPane.PLAIN_MESSAGE);
        state.restart();
        ui.board_panel.repaint();
    }

}