import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class BoardPanel extends JPanel
{
    public static int size;
    public static int x = 170;
    public static int y = 20;
    public static int width = 45;
    public static int height = 40;

    public BoardPanel()
    {}

    public void setSize(int size)
    {
        this.size = size;
    }

    public void paint(Graphics graphics)
    {
        super.paint(graphics);

        Font font = new Font("Times New Roman", Font.BOLD, 16);
        graphics.setColor(Color.black);
        graphics.setFont(font);
		for(int i=0; i<this.size; i++) {
            graphics.drawString(Character.toString((char)((int)'A'+i)), this.x-30, this.y+this.height*i+5);
			graphics.drawLine(this.x, this.y+this.height*i, this.x+this.width*(this.size-1), this.y+this.height*i);
		}
		for(int j=0; j<this.size; j++) {
            graphics.drawString(String.valueOf(j+1), this.x+this.width*j-5, this.y+this.height*(this.size-1)+30);
			graphics.drawLine(this.x+this.width*j, this.y, this.x+this.width*j, this.y+this.height*(this.size-1));
		}
    }
}