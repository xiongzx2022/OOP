import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import javafx.util.*;

public class FinalJudge
{
    public static boolean isFive(ChessState state) {
        int x = state.x_history.peek();
        int y = state.y_history.peek();
        int size = state.getChessPos().size()-1;
        int color = state.getTurn();
        ArrayList<ArrayList<Integer>> board = state.getChessPos();

        int count = 1;      //本身一点为 1
        int posX = 0;
        int posY = 0;
        /**判断水平方向上的胜负
        /* 将水平方向以传入的点x上的y轴作为分隔线分为两部分
         * 先向左边遍历，判断到的相同的连续的点  count++
         */
        for(posX = x - 1; posX >= 0 ; posX--) {
            if (board.get(posX).get(y) == color) {
                count++;
                if (count >= 5) {
                    return true;
                }
            }else {
                break;
            }
        }    //向右边遍历
        for(posX = x + 1; posX <= size; posX++) {
            if (board.get(posX).get(y) == color) {
                count++;
                if (count >= 5) {
                    return true;
                }
            }else {
                break;
            }
        }
        count = 1;
        /**判断垂直方向上的胜负
        /* 将垂直方向以传入的点y上的x轴作为分隔线分为两部分
         * 先向上遍历，判断到的相同的连续的点  count++
         */
        for(posY = y - 1; posY >= 0; posY--) {
            if (board.get(x).get(posY) == color) {
                count++;
                if (count >= 5) {
                    return true;
                }
            }else {
                break;
            }
        }//向下遍历
        for(posY = y + 1; posY <= size; posY++) {
            if (board.get(x).get(posY) == color) {
                count++;
                if (count >= 5) {
                    return true;
                }
            }else {
                break;
            }
        }
        count = 1;
        /**判断左上右下方向上的胜负
         * 以坐标点为分割线，将棋盘分为左右两个等腰三角形
         * 先判断左边的
         */
        for(posX = x - 1, posY = y - 1; posX >= 0 && posY >= 0; posX--, posY--) {
            if (board.get(posX).get(posY) == color) {
                count++;
                if (count >= 5) {
                    count = 1;
                    return true;
                }
            }else {
                break;
            }
        }//判断右边的
        for(posX = x + 1, posY = y + 1; posX <= size && posY <= size; posX++, posY++) {
            if (board.get(posX).get(posY) == color) {
                count++;
                if (count >= 5) {
                    count = 1;
                    return true;
                }
            }else {
                break;
            }
        }
        count = 1;
        /**判断右下左下方向上的胜负
         * 以坐标点为分割线，将棋盘分为左右两个等腰三角形
         * 先判断左边的
         */
        for(posX = x + 1, posY = y - 1; posX <= size && posY >= 0; posX++, posY--) {
            if (board.get(posX).get(posY) == color) {
                count++;
                if (count >= 5) {
                    return true;
                }
            }else {
                break;
            }
        }//判断右边的
        for(posX = x - 1, posY = y + 1; posX >= 0 && posY <= size; posX--, posY++) {
            if (board.get(posX).get(posY) == color) {
                count++;
                if (count >= 5) {
                    return true;
                }
            }else {
                break;
            }
        }
        return false;
    }

    public static boolean checkFive(BoardUI ui, ChessState state){
        String name = "";
        if(state.getTurn()==1) name = "黑方";
        if(state.getTurn()==-1) name = "白方";
        if(isFive(state))
        {

            JOptionPane.showMessageDialog(null, name + "胜利", "游戏结束", JOptionPane.PLAIN_MESSAGE);
            state.restart();
            ui.board_panel.repaint();
            return true;
        }
        return false;
    }

    public static boolean checkFull(BoardUI ui, ChessState state){
		boolean isOver = true;
		for(int i=0; i<state.getChessPos().size(); i++)
		{
			for(int j=0; j<state.getChessPos().size(); j++)
				if(state.getChessPos().get(i).get(j)==0)
					isOver = false;
		}
		if(isOver)
		{
            JOptionPane.showMessageDialog(null, "平局", "游戏结束", JOptionPane.PLAIN_MESSAGE);
            state.restart();
            ui.board_panel.repaint();
		}
        return isOver;
	}

	public static void checkGoOver(BoardUI ui, ChessState state, boolean tromp){
        ArrayList<ArrayList<Integer>> board = state.getChessPos();
        int score_white = 0;
        int score_black = 0;
        int winner = 0;

        for(int i=0; i<board.size(); i++)
            for(int j=0; j<board.size(); j++)
            {
                if(board.get(i).get(j) == 1) score_black++;
                else if(board.get(i).get(j) == -1) score_white++;
            }

        if(tromp)
        {
            int[] reach = getScore(board);
            score_white += reach[0];
            score_black += reach[1];
        }
        else
        {
            for(int i=0; i<board.size(); i++)
                for(int j=0; j<board.size(); j++)
                {
                    int cnt_black = 0;
                    int cnt_white = 0;
                    int cnt_ = 0;
                    if(board.get(i).get(j) == 0)
                    {
                        int[][] xy = {{i-1,j}, {i+1,j}, {i,j-1}, {i,j+1}};
                        for(int k=0; k<xy.length; k++)
                        {
                            int x = xy[k][0];
                            int y = xy[k][1];
                            if(x<0 || x>=board.size() || y<0 || y>=board.size()) continue;
                            if(board.get(x).get(y) == 1) cnt_black++;
                            if(board.get(x).get(y) == -1) cnt_white++;
                            cnt_++;
                        }
                    }
                    if(cnt_black == cnt_) score_black++;
                    else if(cnt_white == cnt_) score_white++;
                }
        }

        //System.out.printf("%d %d\n", score_black, score_white);
        if(score_black > score_white)
            JOptionPane.showMessageDialog(null, "黑方胜利", "游戏结束", JOptionPane.PLAIN_MESSAGE);
        else
            JOptionPane.showMessageDialog(null, "白方胜利", "游戏结束", JOptionPane.PLAIN_MESSAGE);
        
        
        state.restart();
        ui.board_panel.repaint();
    }

    public static int[] getScore(ArrayList<ArrayList<Integer>> board){
        HashMap< Pair<Integer,Integer>, Pair<Boolean,Boolean> > reachability = new HashMap< Pair<Integer,Integer>, Pair<Boolean,Boolean> >();
        
        HashMap< Pair<Integer,Integer>, ArrayList<Pair<Integer,Integer>> > empty_neighbors = new HashMap< Pair<Integer,Integer>, ArrayList<Pair<Integer,Integer>> >();
        for(int i=0; i<board.size(); i++)
            for(int j=0; j<board.size(); j++)
            {
                if(board.get(i).get(j) == 0)
                {
                    reachability.put(new Pair<Integer,Integer>(i,j), new Pair<Boolean,Boolean>(false,false));
                    empty_neighbors.put(new Pair<Integer,Integer>(i,j), new ArrayList<Pair<Integer,Integer>>());
                }
            }
        for(int i=0; i<board.size(); i++)
            for(int j=0; j<board.size(); j++)
            {
                if(board.get(i).get(j) == 0)
                {
                    Pair<Integer,Integer> empty = new Pair<Integer,Integer>(i,j);
                    int[][] xy = {{i-1,j}, {i+1,j}, {i,j-1}, {i,j+1}};
                    for(int k=0; k<xy.length; k++)
                    {
                        Pair<Integer,Integer> pos = new Pair<Integer,Integer>(xy[k][0],xy[k][1]);
                        if(pos.getKey()<0 || pos.getKey()>=board.size() || pos.getValue()<0 || pos.getValue()>=board.size()) continue;
                        if(board.get(pos.getKey()).get(pos.getValue()) == 1)
                            reachability.put(empty, new Pair<Boolean,Boolean>(reachability.get(empty).getKey() || true, reachability.get(empty).getValue()));
                        else if(board.get(pos.getKey()).get(pos.getValue()) == -1)
                            reachability.put(empty, new Pair<Boolean,Boolean>(reachability.get(empty).getKey(), reachability.get(empty).getValue() || true));
                        else
                        {   
                            ArrayList<Pair<Integer,Integer>> array = empty_neighbors.get(empty);
                            array.add(pos);
                            empty_neighbors.put(empty, array);
                        }
                    }
                }
            }
        while(true)
        {
            boolean changed = false;
            for(int i=0; i<board.size(); i++)
                for(int j=0; j<board.size(); j++)
                {
                    if(board.get(i).get(j) == 0)
                    {
                        Pair<Integer,Integer> empty = new Pair<Integer,Integer>(i,j);
                        ArrayList<Pair<Integer,Integer>> array = empty_neighbors.get(empty);
                        for(int k=0; k<array.size(); k++)
                        {
                            Pair<Integer,Integer> neighber = array.get(k);
                            boolean black_reach = reachability.get(neighber).getKey();
                            boolean white_reach = reachability.get(neighber).getValue();
                            Pair<Boolean,Boolean> tmp_empty_reach = reachability.get(empty);
                            if((tmp_empty_reach.getKey() || black_reach) != tmp_empty_reach.getKey() || (tmp_empty_reach.getValue() || white_reach) != tmp_empty_reach.getValue())
                            {
                                reachability.put(empty, new Pair<Boolean,Boolean>(tmp_empty_reach.getKey() || black_reach, tmp_empty_reach.getValue() || white_reach));
                                changed = true;
                            }
                        }
                    }
                }
            if(!changed) break;
        }

        int black_score = 0;
        int white_score = 0;

        for(Pair<Boolean,Boolean> reach : reachability.values())
        {
            if(reach.getKey()==true && reach.getValue()==false) black_score++;
            if(reach.getKey()==false && reach.getValue()==true) white_score++;
        }

        return new int[]{black_score, white_score};
        
    }
}