import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class Listener implements MouseListener, ActionListener
{
    private BoardUI ui;
    private ChessState state;
    private ChessStateCareTaker state_taker;

    public Listener(BoardUI ui){
		this.ui = ui;
        this.state_taker = new ChessStateCareTaker();
	}

    public void mousePressed(MouseEvent e){	
		boolean result = ChessJudge.makeMove(this.ui, this.state, e.getX(), e.getY());
		if(!result) return;				

		if(this.state.getType() == "围棋")
		{
			ChessJudge.updateBoard(this.ui, this.state);
		}
		else if(this.state.getType() == "五子棋")
		{
			if(FinalJudge.checkFive(this.ui, state) || FinalJudge.checkFull(this.ui, state))
				return;
		}
		
		this.state.change();
	}

	public void actionPerformed(ActionEvent e) {
		switch(e.getActionCommand())
		{
			case "开始新游戏": this.state = BaseJudge.selectGame(this.ui); break;
			case "加载存档":
				this.state = BaseJudge.loadGame(this.state_taker, this.state);
				ChessJudge.updateBoard(this.ui, this.state);
				break;
			case "保存当前游戏": BaseJudge.saveGame(this.state_taker, this.state); break;
			case "过子": 
				ChessJudge.pass(this.state);
				FinalJudge.checkGoOver(ui, state, true);
				break;
			case "悔棋":
				this.state = ChessJudge.regret(this.state);
				ChessJudge.updateBoard(this.ui, this.state);
				break;
			case "认输": BaseJudge.giveUp(this.ui, this.state); break;
		}
	}
    
    public void mouseClicked(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
}