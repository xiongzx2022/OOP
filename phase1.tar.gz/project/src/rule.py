def get_winner(self, tromp=True):
    """Calculate score of board state and return player ID (1, -1)
    corresponding to winner. Uses 'Tromp-Taylor scoring' or 'Area scoring'.
    """
    # Count number of positions filled by each player, plus 1 for each eye-ish space owned
    score_white = np.sum(self.board == WHITE)
    score_black = np.sum(self.board == BLACK)
    if tromp:
        black_reach, white_reach = self.get_score_of_empty()
        score_white += white_reach
        score_black += black_reach
    else:
        empties = zip(*np.where(self.board == EMPTY))
        for empty in empties:
            # Check that all surrounding points are of one color
            if self.is_eyeish(empty, BLACK):
                score_black += 1
            elif self.is_eyeish(empty, WHITE):
                score_white += 1
        score_white -= self.passes_white
        score_black -= self.passes_black
    score_white += self.komi
    if score_black > score_white:
        winner = BLACK
    else:
        winner = WHITE
    return winner

def get_score_of_empty(self):
    """Calculate score for empty positions of board state using Tromp-Taylor scoring.
       Returns BLACK_score, WHITE_score
    """
    empties = zip(*np.where(self.board == EMPTY))
    empty_neighbors = {}
    reachability = {}
    for empty in empties:
        reachability[empty] = (False, False) # reachability of the empty postion from BLACK, WHITE.
        empty_neighbors[empty] = []
    for empty in empties:
        for (nx, ny) in self._neighbors(empty):
            if self.board[nx, ny] == BLACK: # 空格的旁边是黑子
                reachability[empty] = (reachability[empty][0]|True, reachability[empty][1])
            elif self.board[nx, ny] == WHITE:   # 空格的旁边是白子
                reachability[empty] = (reachability[empty][0], reachability[empty][1]|True)
            else :  # 邻居为空
                empty_neighbors[empty].append((nx, ny))
    # propagate reachability
    reachability_old = reachability.copy()
    while True:
        for empty in empties:
            for (nx, ny) in empty_neighbors[empty]: # 对每一个空格的空邻居
                black_reach, white_reach = reachability[(nx, ny)]   # 空邻居的黑白连接
                reachability[empty] = (reachability[empty][0]|black_reach,reachability[empty][1]|white_reach)   # 邻居能连，自己就能连
        if reachability_old == reachability:    # 如果没变就中断
            break
        else :  # 继续传递
            reachability_old = reachability.copy()
    BLACK_score = 0
    WHITE_score = 0
    for empty, (br, wr) in reachability.items():
        if (br, wr) == (True, False):
            BLACK_score += 1
        elif (br, wr) == (False, True):
            WHITE_score += 1
        else:
            pass
    return BLACK_score, WHITE_score