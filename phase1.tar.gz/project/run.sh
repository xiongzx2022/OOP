rm ./bin/*.class
javac ./src/demo.java -sourcepath ./src/ -d ./bin/
java -classpath ./bin/ demo